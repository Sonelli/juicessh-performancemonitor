#!/bin/bash

. release-common.sh

rm $LOG_FILE
log "Starting release" 

#./release-dist-branch.sh || exit 1
#./release-sdk-branch.sh || exit 1
#./release-dist-sdk-test-branch.sh || exit 1
#
#./release-dist-master.sh || exit 1
#./release-sdk-master.sh || exit 1
#
#./release-git-push.sh || exit 1
#
#./release-dist-zip.sh || exit 1
#
#./release-dist-deb.sh || exit 1
#./release-dist-rpm.sh || exit 1
#
#./release-sdk-herd.sh || exit 1
